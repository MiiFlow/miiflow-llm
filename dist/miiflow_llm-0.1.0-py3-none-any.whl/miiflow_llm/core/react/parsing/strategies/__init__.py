"""Parsing strategies for ReAct responses - now deprecated.

The strategies directory is kept for backward compatibility but is no longer used.
XML parsing has replaced JSON-based parsing with healing strategies.
"""

__all__ = []
